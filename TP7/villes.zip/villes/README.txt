The file villes.txt contains the approximate coordinates (lattitudes
and longitudes in decimal degrees) of towns in Metropolitan France.
Note that, due to approximation, a few towns have identical coordinates.

This file has been derived from data available at web site
http://www.galichon.com/codesgeo/, which itself has been composed
from data available at INSEE and other organisms.

Please make sure that you read the warning at
http://www.galichon.com/codesgeo/avertissement.php
